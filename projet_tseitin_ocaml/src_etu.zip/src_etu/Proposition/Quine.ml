open Formule

(* Compléter ce fichier avec les éléments du fichier Quine.ml du TP 2 nécessaires pour le projet,
   en plus des définitions ci-dessous. *)

(** subst g s f : substitue une formule g à un atome s dans une formule f. *)
let subst : formule -> string -> formule -> formule =
  let rec aux g s f =
    match f with
    | Atome m when m = s -> g
    | Top | Bot | Atome _ -> f
    | Non a -> Non (aux g s a)
    | Et (f0, f1) -> Et (aux g s f0, aux g s f1)
    | Ou (f0, f1) -> Ou (aux g s f0, aux g s f1)
    | Imp (f0, f1) -> Imp (aux g s f0, aux g s f1)
    | Equiv (f0, f1) -> Equiv (aux g s f0, aux g s f1)
  in
  aux

(** Choisit un atome d'une formule, renvoyant None si aucun n'est présent.*)
let choix_atome : formule -> string option =
  let rec aux f =
    match f with
    | Top | Bot -> None
    | Atome a -> Some a
    | Non a -> aux a
    | Et (f0, f1) | Ou (f0, f1) | Imp (f0, f1) | Equiv (f0, f1) -> (
        match aux f0 with None -> aux f1 | Some a -> Some a)
  in
  aux

(** Simplifie une formule d'une manière paresseuse. *)
let simplif_quine : formule -> formule =
  let rec aux = function
    | Ou (f, g) -> (
        match aux f with
        | Bot -> aux g
        | Top -> Top
        | f' -> ( match aux g with Bot -> f' | Top -> Top | g' -> Ou (f', g')))
    | Et (f, g) -> (
        match aux f with
        | Bot -> Bot
        | Top -> aux g
        | f' -> ( match aux g with Bot -> Bot | Top -> f' | g' -> Et (f', g')))
    | (Bot | Top | Atome _) as f -> f
    | Non f -> ( match aux f with Top -> Bot | Bot -> Top | f' -> Non f')
    | Imp (f, g) -> (
        match aux f with
        | Bot -> Bot
        | Top -> aux g
        | f' -> ( match aux g with Bot -> Bot | Top -> f' | g' -> Imp (f', g')))
    | Equiv (f, g) -> (
        match aux f with
        | Bot -> Bot
        | Top -> aux g
        | f' -> ( match aux g with Bot -> Bot | Top -> f' | g' -> Equiv (f', g')))
  in
  aux

(** Teste si une formule est satisfaisable, selon l'algorithme de Quine. *)
let quine_sat (f : formule) : bool =
  let rec aux f =
    match choix_atome f with
    | Some a ->
        aux (simplif_quine (subst Bot a f))
        || aux (simplif_quine (subst Top a f))
    | None -> ( match simplif_quine f with Top -> true | _ -> false)
  in
  aux f
