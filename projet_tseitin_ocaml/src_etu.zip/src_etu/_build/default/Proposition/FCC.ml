open Formule

(* Compléter ce fichier avec les éléments du fichier FCC.ml du TP 3 nécessaires pour le projet,
   en plus des définitions ci-dessous. *)

(** Signe d'un littéral. *)
type signe = Plus | Moins

type litteral = signe * string
(** Type d'un littéral : produit d'un signe et d'un atome (string). *)

(** Le module Clause permet de manipuler les ensembles
    de littéraux. Il est généré via le foncteur Set.Make. *)
module Clause = Set.Make (struct
  type t = litteral

  let compare = Stdlib.compare
end)

type clause = Clause.t
(** Type synonyme : une clause est un ensemble de littéraux. *)

(** Le module FormeClausale permet de manipuler les ensembles
      de clauses. Il est généré via le foncteur Set.Make. *)
module FormeClausale = Set.Make (struct
  type t = clause

  let compare x y =
    let c = Stdlib.compare (Clause.cardinal x) (Clause.cardinal y) in
    if c <> 0 then c else Clause.compare x y
end)

type forme_clausale = FormeClausale.t
(** Type synonyme : une forme clausale est un ensemble de clauses. *)

(** Mise en FCC, étape 1 : Transforme une formule en une formule équivalente avec des opérateurs 
    de conjonction, de disjonction, de négation, Bot et Top uniquement. *)
let retrait_operateurs (f : formule) : formule =
  let rec aux f =
    match f with
    | Imp (x, y) -> aux (Ou (Non x, y))
    | (Bot | Top | Atome _) as f -> f
    | Ou (f1, f2) -> Ou (aux f1, aux f2)
    | Et (f1, f2) -> Et (aux f1, aux f2)
    | Non f1 -> Non (aux f1)
    | Equiv (f1, f2) ->
        let transforme_f1 = aux f1 in
        let transforme_f2 = aux f2 in
        Non
          (Ou
             ( Et (transforme_f1, Non transforme_f2),
               Et (Non transforme_f1, transforme_f2) ))
  in
  aux f

(** Mise en FCC, étape 2 : Descend les négations dans une formule au plus profond de l'arbre syntaxique,
    en préservant les évaluations. *)
let descente_non (f : formule) : formule =
  let rec aux f =
    match f with
    | (Bot | Top | Atome _ | Non (Atome _)) as f -> f
    | Non Bot -> Top
    | Non Top -> Bot
    | Non (Non f') -> aux f'
    | Non (Et (f1, f2)) -> Ou (aux f1, aux f2)
    | Non (Ou (f1, f2)) -> Et (aux f1, aux f2)
    | Et (f1, f2) -> Et (aux f1, aux f2)
    | Ou (f1, f2) -> Ou (aux f1, aux f2)
    | Non (Imp _) | Imp _ | Non (Equiv _) | Equiv _ ->
        failwith
          "descente_non ne peux pas contenir d'expression avec des Imp ou des \
           Equiv."
  in
  aux f

(* Inversion d'un signe.*)
let neg_sign : signe -> signe = function Plus -> Moins | Moins -> Plus

(* Inversion du signe d'un littéral.*)
let neg_lit ((s, atome) : litteral) : litteral = (neg_sign s, atome)

(* Fait le profuit cartésien entre fc1 et fc2 *)
let produit_cart fc1 fc2 =
  FormeClausale.fold
    (fun cl1 acc1 ->
      FormeClausale.fold
        (fun cl2 acc2 -> FormeClausale.add (Clause.union cl1 cl2) acc2)
        fc2 acc1)
    fc1 FormeClausale.empty

(** Mise en FCC, étape 3 : calcule la forme clausale associée à une formule. *)
let forme_ensembliste (f : formule) : forme_clausale =
  let rec aux f =
    match f with
    | Top -> FormeClausale.singleton Clause.empty
    | Bot -> FormeClausale.empty
    | Atome x -> FormeClausale.singleton (Clause.singleton (Plus, x))
    | Et (f1, f2) -> FormeClausale.union (aux f1) (aux f2)
    | Non f ->
        FormeClausale.map
          (Clause.map (fun (signe, x) -> (neg_sign signe, x)))
          (aux f)
    | Imp (f1, f2) -> FormeClausale.union (aux (Non f1)) (aux f2)
    | Equiv (f1, f2) -> aux (Ou (Et (f1, f2), Et (Non f1, Non f2)))
    | Ou (f1, f2) -> produit_cart (aux f1) (aux f2)
  in
  aux f

(** Convertit une formule en une forme clausale conjonctive équivalente.*)
let formule_to_fcc (f : formule) : forme_clausale =
  forme_ensembliste (descente_non (retrait_operateurs f))

let fcc_to_list (c : forme_clausale) : litteral list list =
  List.map Clause.elements (FormeClausale.elements c)
