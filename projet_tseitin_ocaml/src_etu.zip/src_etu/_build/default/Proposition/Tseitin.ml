open Formule

let f1 = Et (Atome "a", Atome "b")
let f2 = Ou (Atome "a", Non (Atome "b"))

let f3 =
  Ou
    ( Et (Et (Atome "a", Atome "b"), Atome "c"),
      Imp (Atome "a", Imp (Atome "a", Atome "c")) )

let f4 = Et (Non (Atome "a"), Non (Atome "b"))

(** Retourne un old_ si c'est un atome sinon un new_ *)
let old_or_new (f : formule) (cpt : int) =
  match f with
  | Atome a -> Atome ("old_" ^ a)
  | _ -> Atome ("new_" ^ string_of_int cpt)

(** Teste si f est un atome *)
let atop (f : formule) : int = match f with Atome _ | Top | Bot -> 0 | _ -> 1

(** Calcule la transformée de Tseitin d'une formule donnée,
    en supposant que la formule ne contienne pas d'opérateur d'équivalence. *)
let tseitin (f : formule) : formule =
  Et
    ( old_or_new f 0,
      let rec tseitin_aux (f' : formule) (cpt : int) =
        match f' with
        | (Atome _ | Top | Bot) as g -> old_or_new g cpt
        | Non g ->
            let r = tseitin_aux g (cpt + 1) in
            let eq = Equiv (old_or_new f' cpt, Non (old_or_new g (cpt + 1))) in
            if atop r == 0 then eq else Et (eq, r)
        | Et (f1, f2) -> (
            let r1 = tseitin_aux f1 (cpt + 1) in
            let h1 = hauteur f1 in
            let r2 = tseitin_aux f2 (cpt + h1) in
            let eq =
              Equiv
                ( old_or_new f' cpt,
                  Et (old_or_new f1 (cpt + 1), old_or_new f2 (cpt + h1)) )
            in
            match (r1, r2) with
            | r1, r2 when atop r1 == 0 && atop r2 == 0 -> eq
            | r1, r2 when atop r1 != 0 && atop r2 == 0 -> Et (eq, r1)
            | r1, r2 when atop r1 == 0 && atop r2 != 0 -> Et (eq, r2)
            | r1, r2 -> Et (eq, Et (r1, r2)))
        | Ou (f1, f2) -> (
            let r1 = tseitin_aux f1 (cpt + 1) in
            let h1 = hauteur f1 in
            let r2 = tseitin_aux f2 (cpt + h1) in
            let eq =
              Equiv
                ( old_or_new f' cpt,
                  Ou (old_or_new f1 (cpt + 1), old_or_new f2 (cpt + h1)) )
            in
            match (r1, r2) with
            | r1, r2 when atop r1 == 0 && atop r2 == 0 -> eq
            | r1, r2 when atop r1 != 0 && atop r2 == 0 -> Et (eq, r1)
            | r1, r2 when atop r1 == 0 && atop r2 != 0 -> Et (eq, r2)
            | r1, r2 -> Et (eq, Et (r1, r2)))
        | Imp (f1, f2) -> (
            let r1 = tseitin_aux f1 (cpt + 1) in
            let h1 = hauteur f1 in
            let r2 = tseitin_aux f2 (cpt + h1) in
            let eq =
              Equiv
                ( old_or_new f' cpt,
                  Imp (old_or_new f1 (cpt + 1), old_or_new f2 (cpt + h1)) )
            in
            match (r1, r2) with
            | r1, r2 when atop r1 == 0 && atop r2 == 0 -> eq
            | r1, r2 when atop r1 != 0 && atop r2 == 0 -> Et (eq, r1)
            | r1, r2 when atop r1 == 0 && atop r2 != 0 -> Et (eq, r2)
            | r1, r2 -> Et (eq, Et (r1, r2)))
        | _ -> failwith "Ne dois pas contenir d'opérateur Equiv ou d'élément n'étant des formules."
      in
      tseitin_aux f 0 )

(** Transforme une interprétation évaluant une transformée de Tseitin T(F) comme vraie
    en une interprétation évaluant la formule de départ F comme vraie. *)
let restrict_inter (i : interpretation) : interpretation =
 fun p ->
  let b = String.sub p 0 4 in
  if b = "old_" then i p
  else failwith "il n'y pas d'interprétation pour des new_"

(** Transforme une interprétation évaluant une formule F comme vraie
    en une interprétation évaluant sa transformée de Tseitin T(F) comme vraie. *)
let extension_inter (_ : interpretation) (_ : formule) : interpretation =
  failwith ""
