(** Le module Formule contient les types et définitions de base
    permettant la manipulation des formules de la logique propositionnelle. *)

(* Compléter ce fichier avec les éléments du fichier Formule.ml du TP 1 nécessaires pour le projet,
   en plus des définitions ci-dessous. *)

(** Type des formules de la logique propositionnelle, avec des string comme atomes. *)
type formule =
  | Bot
  | Top
  | Atome of string
  | Imp of (formule * formule)
  | Ou of (formule * formule)
  | Et of (formule * formule)
  | Non of formule
  | Equiv of (formule * formule)

type interpretation = string -> bool

(** Calcule la hauteur de l'arbre syntaxique d'une formule. *)
let hauteur (f : formule) : int =
  let rec aux f =
    match f with
    | Top | Bot | Atome _ -> 1
    | Et (f, g) | Ou (f, g) | Imp (f, g) | Equiv (f, g) ->
        1 + max (aux f) (aux g)
    | Non f -> 1 + aux f
  in
  aux f

(** Conversion d'une formule en chaîne de caractères. *)
let string_of_formule : formule -> string =
  let rec aux = function
    | Top -> "⊤"
    | Bot -> "⊥"
    | Atome s -> s
    | Imp (f, g) -> "(" ^ aux f ^ " -> " ^ aux g ^ ")"
    | Et (f, g) -> "(" ^ aux f ^ " ∧ " ^ aux g ^ ")"
    | Ou (f, g) -> "(" ^ aux f ^ " ∨ " ^ aux g ^ ")"
    | Non s -> "¬" ^ aux s
    | Equiv (f, g) -> "(" ^ aux f ^ " ⇔ " ^ aux g ^ ")"
  in
  aux

(** Évalue une formule en fonction d'une interprétation. *)
let eval (i : interpretation) : formule -> bool =
  let rec aux i = function
    | Top -> true
    | Bot -> false
    | Atome s -> i s
    | Ou (f, g) -> aux i f || aux i g
    | Et (f, g) -> aux i f && aux i g
    | Imp (f, g) -> aux i f <= aux i g
    | Non s -> not (aux i s)
    | Equiv (f, g) -> aux i f = aux i g
  in
  aux i

(** Transforme une liste de couples string en une interprétation. *)
let interpretation_of_list (sl : string list) (s : string) : bool =
  List.mem s sl
