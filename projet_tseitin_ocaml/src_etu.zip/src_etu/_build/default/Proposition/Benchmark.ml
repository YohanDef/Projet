open Formule
open Tseitin
open FCC
open DPLL
open RandomFormule
open CorrecTest

(* Mesure du temps d'exécution d'une formule donc sur un paramètre arg
   renvoyant le couple (résultat, temps de calcul). *)
let mesure fonc arg =
  let debut = Sys.time () in
  let res = fonc arg in
  let fin = Sys.time () in
  (res, fin -. debut)

let bench_dpll (f : formule) : unit =
  if contain_equiv f then
    failwith "On ne traite pas les 'Equivalences' dans les formules \n"
  else (
    print_string ("F = " ^ string_of_formule f ^ "\n");
    let f' = tseitin f in
    Printf.printf "T(F) = %s\nTransformation : %fs\n" (string_of_formule f')
      (snd (mesure tseitin f));
    let fcc = formule_to_fcc f in
    let a, b =
      ( List.length (fcc_to_list fcc),
        List.fold_left (fun acc e -> acc + List.length e) 0 (fcc_to_list fcc) )
    in
    Printf.printf "fcc (F) : %fs (%d clauses, %d littéraux)\n"
      (snd (mesure formule_to_fcc f))
      a b;
    let fcc' = formule_to_fcc f' in
    let a', b' =
      ( List.length (fcc_to_list fcc'),
        List.fold_left (fun acc e -> acc + List.length e) 0 (fcc_to_list fcc')
      )
    in
    Printf.printf "fcc (T(F)) : %fs (%d clauses, %d littéraux)\n"
      (snd (mesure formule_to_fcc f'))
      a' b';
    let sat_ffc = dpll_sat_unit_prop fcc' in
    let sat_ffc' = dpll_sat_unit_prop fcc' in
    Printf.printf "Dpll (F) : %b (%fs)\n" sat_ffc
      (snd (mesure dpll_sat_unit_prop fcc'));
    Printf.printf "Dpll (T(F)) : %b (%fs)\n" sat_ffc'
      (snd (mesure dpll_sat_unit_prop fcc')))

let bench_dpll' (l : string list) (n : int) : unit =
  let f = random_form l n in
  bench_dpll f
